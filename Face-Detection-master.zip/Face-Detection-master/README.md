# Face Detection using Python

Detects the faces in any image , video or any live cam

## Tech Stack

It uses Python library **Open CV**
and uses the **Haar cascade** algorithm to detect the face
